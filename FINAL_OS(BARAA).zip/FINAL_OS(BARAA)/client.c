#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <pthread.h>

#define PIPE_NAME_SEND "/tmp/my_named_pipe_send"
#define PIPE_NAME_RECV "/tmp/my_named_pipe_recv"
#define MAX_MESSAGE_LENGTH 100
#define MAX_NAME_LENGTH 50
#define EXIT_COMMAND "exit"

void *listen_for_messages(void *arg) {
    char *my_pipe = (char *)arg;
    int fd = open(my_pipe, O_RDONLY);
    char buffer[MAX_MESSAGE_LENGTH];

    while (1) {
        ssize_t count = read(fd, buffer, MAX_MESSAGE_LENGTH);
        if (count > 0) {
            printf("\nReceived: %s\n", buffer);
            printf("Enter your message: ");
            fflush(stdout);
        } else {
            perror("Failed to read from the pipe");
            close(fd);
            free(my_pipe);
            exit(EXIT_FAILURE);
        }
    }

    close(fd);
    free(my_pipe);
    return NULL;
}

int main() {
    pthread_t thread_id;
    int fd_send;
    char message[MAX_MESSAGE_LENGTH];
    char client_name[MAX_NAME_LENGTH];
    char full_message[MAX_MESSAGE_LENGTH + MAX_NAME_LENGTH];
    char *my_recv_pipe = malloc(MAX_NAME_LENGTH + 20);

    printf("Enter your name: ");
    fgets(client_name, MAX_NAME_LENGTH, stdin);
    client_name[strcspn(client_name, "\n")] = 0;

    snprintf(my_recv_pipe, MAX_NAME_LENGTH + 20, "/tmp/%s_pipe", client_name);
    mkfifo(my_recv_pipe, 0666);

    snprintf(full_message, sizeof(full_message), "%s has joined the chat", client_name);

    fd_send = open(PIPE_NAME_SEND, O_WRONLY);
    if (fd_send == -1) {
        perror("Failed to open named pipe for writing");
        exit(EXIT_FAILURE);
    }

    write(fd_send, full_message, strlen(full_message) + 1);
    close(fd_send);

    pthread_create(&thread_id, NULL, listen_for_messages, my_recv_pipe);

    while (1) {
        printf("Enter your message: ");
        fflush(stdout);
        fgets(message, MAX_MESSAGE_LENGTH, stdin);
        message[strcspn(message, "\n")] = 0;

        if (strcmp(message, EXIT_COMMAND) == 0) {
            break;
        }

        snprintf(full_message, sizeof(full_message), "%s: %s", client_name, message);

        fd_send = open(PIPE_NAME_SEND, O_WRONLY);
        if (fd_send == -1) {
            perror("Failed to open named pipe for writing");
            continue;
        }

        write(fd_send, full_message, strlen(full_message) + 1);
        close(fd_send);
    }

    pthread_cancel(thread_id);
    pthread_join(thread_id, NULL);

    unlink(my_recv_pipe);
    free(my_recv_pipe);

    return 0;
}