#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

#define PIPE_NAME_SEND "/tmp/my_named_pipe_send"
#define MAX_THREADS 1  // Adjust as needed
#define BUFFER_SIZE 100
#define SEM_NAME "/my_semaphore"  // Name for the named semaphore

int client_fds[MAX_THREADS];
int client_count = 0;
pthread_mutex_t mutex;
sem_t *connection_semaphore;

void broadcast_message(const char *message, int sender_fd) {
    pthread_mutex_lock(&mutex);
    for (int i = 0; i < client_count; ++i) {
        if (client_fds[i] != sender_fd) {
            write(client_fds[i], message, strlen(message) + 1);
        }
    }
    pthread_mutex_unlock(&mutex);
}

void *handle_client(void *arg) {
    int fd = *(int *)arg;
    free(arg);

    char buffer[BUFFER_SIZE];
    while (1) {
        ssize_t count = read(fd, buffer, BUFFER_SIZE);
        if (count > 0) {
            printf("Server: Received Message: %s\n", buffer);
            broadcast_message(buffer, fd);
        } else {
            break; // Client disconnected or error
        }
    }

    pthread_mutex_lock(&mutex);
    for (int i = 0; i < client_count; ++i) {
        if (client_fds[i] == fd) {
            client_fds[i] = client_fds[--client_count];
            break;
        }
    }
    pthread_mutex_unlock(&mutex);

    close(fd);
    sem_post(&connection_semaphore); // Release a slot when client disconnects
    return NULL;
}

int main() {
    pthread_mutex_init(&mutex, NULL);
    connection_semaphore = sem_open(SEM_NAME, O_CREAT, 0644, MAX_THREADS);
    if (connection_semaphore == SEM_FAILED) {
        perror("sem_open failed");
        exit(EXIT_FAILURE);
    }

    mkfifo(PIPE_NAME_SEND, 0666);
    printf("Server: Waiting for client...\n");

     while (1) {
        sem_wait(&connection_semaphore); // Wait for an available slot

        // Accept a connection
        int client_fd = open(PIPE_NAME_SEND, O_RDONLY);
        if (client_fd == -1) {
            perror("Failed to open named pipe");
            sem_post(&connection_semaphore); // Release the slot on error
            continue;
        }

        // Allocate memory for the file descriptor
        int *fd_ptr = malloc(sizeof(int));
        if (fd_ptr == NULL) {
            perror("Failed to allocate memory for file descriptor");
            close(client_fd);
            sem_post(&connection_semaphore); // Release the slot on error
            continue;
        }
        *fd_ptr = client_fd;

        // Lock mutex to modify shared resources
        pthread_mutex_lock(&mutex);

        // Check if we've reached the maximum number of clients
        if (client_count >= MAX_THREADS) {
            pthread_mutex_unlock(&mutex);
            free(fd_ptr);
            close(client_fd);
            sem_post(&connection_semaphore); // Release the slot
            continue;
        }

        printf("Server: Client connected. Spawning thread...\n");

        // Create a detached thread for the client
        pthread_t thread_id;
        if (pthread_create(&thread_id, NULL, handle_client, fd_ptr) != 0) {
            perror("Failed to create thread");
            pthread_mutex_unlock(&mutex);
            free(fd_ptr);
            close(client_fd);
            sem_post(&connection_semaphore); // Release the slot on error
            continue;
        }

        // Detach the new thread
        pthread_detach(thread_id);
        
        // Increase client count
        client_fds[client_count++] = *fd_ptr;

        // Unlock mutex after modifying shared resources
        pthread_mutex_unlock(&mutex);
    }

    // Cleanup (unreachable in this code)
   sem_close(connection_semaphore);
    sem_unlink(SEM_NAME);
    pthread_mutex_destroy(&mutex);
    unlink(PIPE_NAME_SEND);


    return 0;
}